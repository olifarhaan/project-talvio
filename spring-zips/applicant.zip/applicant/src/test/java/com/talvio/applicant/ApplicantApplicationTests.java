package com.talvio.applicant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicantApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.talvio.job_seeker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobSeekerApplicationTests {

	@Test
	void contextLoads() {
	}

}
